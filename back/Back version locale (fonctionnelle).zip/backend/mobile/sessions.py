import sys
from flask import request, jsonify
from utils import *
from db import *
from __main__ import app
from datetime import datetime
from flask_jwt_extended import jwt_required, get_jwt_identity
import uuid

# Mapper les noms de colonnes à renommer
column_mapping = {
    'id_session': 'id',
    'date_creation': 'createdAt',
    'date_session': 'sessionDate',
    'date_maj': 'updatedAt',
    'apex0': 'apexFullGrowth',
    'apex1': 'apexSlowerGrowth',
    'apex2': 'apexStuntedGrowth',
    'id_observateur': 'observerId',
    'id_parcelle': 'parcelId',
    'id_stade': 'stadePhenoId',
    'commentaire': 'notes',
    'device_hardware': 'deviceHardware',
    'device_software': 'deviceSoftware',
    'en_parcelle': 'inField',
    'latitude': 'latitude',
    'longitude': 'longitude',
}

def changeDateFormat(session):
    session['sessionDate'] = session['sessionDate'].strftime('%Y-%m-%d')
    return session


@app.route('/sessions')
@jwt_required()
def getAuthorizedSessions():
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    # Check si l'user est l'observateur des sessions
    # Si l'user à accès à la parcelle partagée, il peut voir toutes les sessions
    # select_query = ('SELECT * FROM session '
    #                'WHERE id_observateur = %s '
    #                'OR id_parcelle IN (SELECT id_parcelle FROM utilisateur_parcelle WHERE id_utilisateur = %s)'
    #                )
    select_query = ('SELECT * FROM session '
                   'WHERE id_parcelle IN (SELECT id_parcelle FROM utilisateur_parcelle WHERE id_utilisateur = %s)'
                    )
    cursor.execute(select_query,(identity, ))
    sessions = cursor.fetchall()

    if sessions is None :
        return jsonify({})

    # Récupérer les noms des colonnes
    column_names = [desc[0] for desc in cursor.description]

    # Créer une liste de dictionnaires associant les noms des colonnes aux valeurs
    result = [dict(zip(column_names, session)) for session in sessions]

    # Renommer les clés du dictionnaire en utilisant le mapping
    for session in result:
        for old_key, new_key in column_mapping.items():
            if old_key in session :
                session[new_key] = session.pop(old_key)
        changeDateFormat(session)

    cursor.close()

    return jsonify(result)


@app.route('/sessions/<string:id>')
@jwt_required()
def getAuthorizedSession(id):
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    # Check si l'user est l'observateur de la session
    # Si l'user à accès à la parcelle partagée, il peut voir la session
    # select_query = ('SELECT * FROM session '
    #                'WHERE id_session = %s AND id_observateur = %s '
    #                'OR id_session = %s AND id_parcelle IN (SELECT id_parcelle FROM utilisateur_parcelle WHERE id_utilisateur = %s)'
    #                )
    select_query = ('SELECT * FROM session '
                   'WHERE id_session = %s '
                   'AND id_parcelle IN (SELECT id_parcelle FROM utilisateur_parcelle WHERE id_utilisateur = %s)'
                   'AND date_session >= (now() - interval 6 month)'
                    )
    cursor.execute(select_query, (id, identity))
    session = cursor.fetchone()

    if session is None :
        return jsonify({})

    # Récupérer les noms des colonnes
    column_names = [desc[0] for desc in cursor.description]

    # Créer une liste de dictionnaires associant les noms des colonnes aux valeurs
    result = [dict(zip(column_names, session))]
    session = result[0]

    # Renommer les clés du dictionnaire en utilisant le mapping
    for old_key, new_key in column_mapping.items():
        if old_key in session :
            session[new_key] = session.pop(old_key)

    cursor.close()

    return jsonify(session)


@app.route('/sessions/<string:id>', methods=['PUT'])
@jwt_required()
def updateAuthorizedSession(id):
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    data = request.get_json()
    # Vérifier que les données sont présentes et valides
    # TODO : ajouter d'autres vérifs sur la présence des données ?
    print(data, file=sys.stderr)
    if not data:
        return jsonify({'message': 'No data provided'}), 400
    if not 'sessionDate' in data or not 'apexFullGrowth' in data or not 'apexSlowerGrowth' in data or not 'apexStuntedGrowth' in data or not 'stadePhenoId' in data or not 'notes' in data :
        return jsonify({'message': 'Missing data'}), 400
    
    update_data = {
        'id_session': 'id',
        'date_session': data['sessionDate'],
        'apex0': data['apexFullGrowth'],
        'apex1': data['apexSlowerGrowth'],
        'apex2': data['apexStuntedGrowth'],
        'id_stade': data['stadePhenoId'],
        'commentaire': data['notes'],
    }
    print('ok3', file=sys.stderr)
    update_query = ('UPDATE session SET ' + ', '.join(f'{key} = %s' for key in update_data.keys()) +
                    'WHERE id_session = %s'
                    'AND id_observateur = %s'
                    )
    update_values = list(update_data.values()) + [id, identity]
    cursor.execute(update_query, update_values)

    db_icapex.commit()
    cursor.close()

    return jsonify({'message': 'Session updated'}), 204


@app.route('/sessions', methods=['POST'])
@jwt_required()
def addSession():
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    data = request.get_json()
    # Vérifier que les données sont présentes et valides
    # TODO : ajouter d'autres vérifs sur la présence des données ?
    if not data:
        return jsonify({'message': 'No data provided'}), 400
    if not 'sessionDate' in data or not 'apexFullGrowth' in data or not 'apexSlowerGrowth' in data or not 'apexStuntedGrowth' in data or not 'parcelId' in data:
        return jsonify({'message': 'Missing data'}), 400


    # Generate a new UUID
    uuid_generated = uuid.uuid4().hex

    latitude = data['latitude']
    longitude = data['longitude']

    # Get parcel to check if lat/lon exist
    select_query = ('SELECT * FROM parcelle '
                    'WHERE id_parcelle = %s '
                    )
    cursor.execute(select_query, (data['parcelId'],))
    parcel = cursor.fetchone()
    if parcel is not None :
        # Récupérer les noms des colonnes
        column_names = [desc[0] for desc in cursor.description]
        # Créer une liste de dictionnaires associant les noms des colonnes aux valeurs
        result = dict(zip(column_names, parcel))
        
        # Si coord de la parcelle ne sont pas nulles ou (0,0), on les attribue à la session si coord session sont nulles
        if result['latitude'] is not None and result['longitude'] is not None and result['latitude'] != 0 and result['longitude'] != 0 :
            if latitude is None and longitude is None :
                latitude = result['latitude']
                longitude = result['longitude']
        # et sinon, on attribue à la parcelle les coord de la session si elles ne sont pas nulles
        elif latitude is not None and longitude is not None :
            update_query = ('UPDATE parcelle SET '
                            'latitude = %s ,'
                            'longitude = %s '
                            'WHERE id_parcelle = %s')
            update_values = (latitude, longitude, data['parcelId'])
            cursor.execute(update_query, update_values)

    # insert session data
    insert_data = {
        'id_session': uuid_generated,
        'date_session': data['sessionDate'],
        'apex0': data['apexFullGrowth'],
        'apex1': data['apexSlowerGrowth'],
        'apex2': data['apexStuntedGrowth'],
        'id_observateur': identity,
        'id_parcelle': data['parcelId'],
        'id_stade': data['stadePhenoId'],
        'commentaire': data['notes'],
        'device_hardware': data['deviceHardware'],
        'device_software': data['deviceSoftware'],
        'en_parcelle': data['inField'],
        'latitude': latitude,
        'longitude': longitude,
    }

    insert_query = ('INSERT INTO session (' + ', '.join(f'{key}' for key in insert_data.keys()) + ') '
                    'VALUES (' + ', '.join(f'%s' for key in insert_data.keys()) + ')'
                    )
    insert_values = list(insert_data.values())
    cursor.execute(insert_query, insert_values)

    db_icapex.commit()
    cursor.close()
    
    return jsonify({'message': 'Session added', 'id': uuid_generated}), 201