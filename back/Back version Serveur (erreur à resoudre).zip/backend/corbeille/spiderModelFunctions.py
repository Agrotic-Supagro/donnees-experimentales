from datetime import datetime, timedelta
from db import *
import statsmodels.api as sm
import numpy as np
import pandas as pd

deltaDate = timedelta(days=3)


#######################################################################################
#############################  SPIDER MODEL COMPUTATION FUNCTIONS  ####################
#######################################################################################

# returns a list of the seasons where PHFB measures have been done
def getSeasonsPHFB():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.Annee FROM session_test GROUP BY Annee'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append(
            row[0] 
        )

    return result

# returns a list of parcel names where PHFB measures have been done
def getParcelNamesPHFB():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle FROM session_test GROUP BY Parcelle'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'name': row[1]  
        }
        )

    return result



# get the valid parcels for spider model computation for the specified season 
# NB: a parcel is valid if there is at least one other parcel that has 3 measure dates in common with that parcel
def validParcelsSpiderModel(seasonYear):
    seasonParcels = getSeasonParcels(seasonYear)
    validParcels = []
    
    # iterate over all possible parcels combination
    for i in range(len(seasonParcels)):
        for j in range(i + 1, len(seasonParcels)):
            if threeCommonMeasures(seasonParcels[i], seasonParcels[j], seasonYear):
                # memorise parcels that match the condition
                if seasonParcels[i] not in validParcels:
                    validParcels.append(seasonParcels[i])
                if seasonParcels[j] not in validParcels:
                    validParcels.append(seasonParcels[j])
    return validParcels


# tells if the two specified parcels have at least 3 measures in common for the specified season (i.e done at the same date)
def threeCommonMeasures(parcelX, parcelY, seasonYear):
    measuresParcelX = getMeasuresParcelSeason(parcelX, seasonYear)
    measuresParcelY = getMeasuresParcelSeason(parcelY, seasonYear)

    i = 0
    nbCommonMeasures = 0
    commonMeasureDates = []
    # iterate over measures on parcelX
    while i < len(measuresParcelX):
        # check if there is a measure at the same date (+/- detalDate) on parcelY
        if measureAtSameDate(measuresParcelY, measuresParcelX[i]['date'], commonMeasureDates) != None:
            nbCommonMeasures = nbCommonMeasures + 1
            commonMeasureDates.append(measuresParcelX[i]['date'])
        if nbCommonMeasures >= 3:
            return True
        i = i + 1
    return False

# tells if the specified date is included in one of time frames defined by dates and deltaDate
def inTimeFrames(date, dates):
    for d in dates:
        if date <= d + deltaDate and date >= d - deltaDate:
            return True
    return False

# TODO: test/verify this function (vérifier notamment si inTimeFrames n'exclue pas plus de parcelles que ce qu'il faudrait)
# if the specified measureDate equals one of the provided measures' dates (+/- delta) returns the phfb value of the matching measure date
# the equality must take place outside of time frames where common measures have already been detected
def measureAtSameDate(measures, measureDate, commonMeasureDates):
    # verify that measureDate is not a date on which measure pairs have already been detected
    if not inTimeFrames(measureDate, commonMeasureDates):
        for measure in measures:
                # verify that measure['date'] is not a date on which measure pairs have already been detected
                if not inTimeFrames(measure['date'], commonMeasureDates):
                    if measure['date'] >= measureDate - deltaDate and measure['date'] <= measureDate + deltaDate:
                        return measure['phfb']
    return None

# get the measures of the specified parcel for the specified season
def getMeasuresParcelSeason(parcel, season_year):
    parcel = parcel.replace('"','') # delete potential '"" character in parcel name
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle, session_test.formatted_date, session_test.PHFB FROM session_test WHERE session_test.Annee = ' + season_year + ' AND session_test.Parcelle = ' + '"' + parcel + '"'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'parcel_name': row[1], 
            'date': row[2],
            'phfb': row[3]
        })
    return result

def getMeasuresSeason(season_year):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle, session_test.formatted_date FROM session_test WHERE session_test.Annee = ' + season_year
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'parcel_name': row[1], 
            'date': row[2]
        })
    return result

# get the number of parcels involved the specified season
def getNumberParcelsSeason(season_year):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'select count(*) from (select session_test.parcelle from session_test where annee = ' + season_year + ' group by session_test.parcelle) as nb_parcels'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            row[0]
        })
    return result

# get the list of the parcels involved the specified season
def getSeasonParcels(season_year):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.parcelle FROM session_test WHERE session_test.Annee = ' + season_year + ' GROUP BY session_test.parcelle'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append(
            row[0]
        )
    return result



# returns the ASI coefficients between the reference parcel and each one of the valid satellite parcels for the specified seasons
def getSpiderCoefficients(seasons, candidateSatelliteParcels, refParcel):
    commonMeasureValues = []
    coeffs = []
    # iterate over seasons
    for season in seasons:
        # get the valid satellite parcels along with their usable measures for the spider model computation for the current season
        computeValidSatelliteParcels(season, candidateSatelliteParcels, refParcel, commonMeasureValues)

    # compute the asi coeffs
    XYMatrix = pd.DataFrame(commonMeasureValues)
    satteliteParcels = XYMatrix['parcel'].unique()

    # iterate over sattelite parcels
    for satParcel in satteliteParcels:
        parcelData = XYMatrix[XYMatrix['parcel'] == satParcel]
        X = parcelData['referenceParcelMeasure'].str.replace(',','.').astype(float)
        Y = parcelData['satelliteParcelMeasure'].str.replace(',','.').astype(float)
        model = sm.OLS(Y,X).fit()
        coeffs.append({'parcel': satParcel, 'coeff': model.params.iloc[0], 'refParcel': refParcel})

    return coeffs

# compute the valid satellite parcels along with their usable measures for spider model computation
# for the specified reference parcel and the specified season
def computeValidSatelliteParcels(season, candidateSatelliteParcels, refParcel, commonMeasureValues):
    # get measures of the reference parcels
    refParcelMeasures = getMeasuresParcelSeason(refParcel, season)

    # compute valid parcels for model computation
    for parcel in candidateSatelliteParcels:
        # get measures of the current parcel
        parcelMeasures = getMeasuresParcelSeason(parcel, season)
        computeSatelliteParcelMeasures(season, parcel, refParcel, parcelMeasures, refParcelMeasures, commonMeasureValues)

# if the specified parcel is valid for spider model computation, returns its usable measures for model computation
# else returns none
def computeSatelliteParcelMeasures(season, parcel, refParcel, parcelMeasures, refParcelMeasures, commonMeasureValues):
    # iterate over parcel's measures
    commonMeasureDates = []
    for parcelMeasure in parcelMeasures:
        # if there is a measure on the ref parcel at the same date than the current measure
        refParcelMeasure = measureAtSameDate(refParcelMeasures, parcelMeasure['date'], commonMeasureDates)
        if refParcelMeasure != None:
            # memorise the measure's date
            commonMeasureDates.append(parcelMeasure['date'])
            # memorise measure values of both parcels (ref parcel + other parcel)
            commonMeasureValues.append({'season': season, 'parcel': parcel, 'satelliteParcelMeasure': parcelMeasure['phfb'], 'referenceParcelMeasure': refParcelMeasure})
    return None

# get measures corresponding to the specified parcels for the specified season
def getMeasuresParcels(season, parcels):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # compute request's parcels list
    parcelsList = '('
    i = 0
    nbParcels = len(parcels)
    while i < nbParcels:
        if i < nbParcels - 1:
            parcelsList = parcelsList + "'" + parcels[i] + "'" + ', '
        else:
            parcelsList = parcelsList + "'" + parcels[i] + "'" + ')'
        i += 1

    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle, session_test.formatted_date, session_test.PHFB FROM session_test WHERE session_test.Parcelle IN ' + parcelsList + ' AND session_test.Annee = ' + season
    )
    data = cursor.fetchall()
    cursor.close()

    # convert result's data 
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'parcel': row[1], 
            'date': row[2],
            'phfb': row[3]
        })
    
    return result

#######################################################################################
#############################  ESTIMATION COMPUTATION FUNCTIONS  ######################
#######################################################################################


# get the reference parcel of the calculated spider model
# if no spider model has been calculated, returns None
def getRefParcelSpiderModel():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    cursor.execute('SELECT coefficients.refParcel FROM coefficients ')
    data = cursor.fetchall()
    cursor.close()
    print('data: ', data)
    for row in data:
        return row[0]
    

def getCoefficients():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # cursor.execute('SELECT coefficients.parcel, coefficients.coeff, coefficients.refParcel FROM coefficients')
    cursor.execute('SELECT coefficients.parcel, coefficients.coeff FROM coefficients')
    data = cursor.fetchall()

    cursor.close()

    result = []
    for row in data:
        result.append({
            'parcel': row[0],
            'coeff': row[1],
        })
        
    return result
    
# compute estimated PHFB values from a new ref measure for all parcels associated to a reference parcel 
def computeEstimationFromRefParcel(refParcel, refParcelMeasure, refParcelMeasureDate, refParcelMeasureYear):
    # get satellite parcels and coeffs
    coeffs = getCoefficients()
    print('laaaaaaaaaaaa')
    # iterate over satellite parcels
    for coeff in coeffs:
        # compute estimated PHFB for current parcel
        estimatedPHFB = str(float(refParcelMeasure) * float(coeff['coeff']))
        # compute mean satellite parcel coordinates
        meanCoord = getParcelCoordinates(coeff['parcel'])
        meanLatitude = str(meanCoord['meanLatitude'])
        meanLongitude = str(meanCoord['meanLongitude'])
        # save estimated values
        savePHFBMeasure(coeff['parcel'], refParcelMeasureDate, refParcelMeasureYear, meanLatitude, meanLongitude, estimatedPHFB, 'estimation')

def savePHFBMeasure(parcel, date, year, latitude, longitude, value, measureType):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    print('savePHFBMeasure parcel: ', parcel)
    # insert new row
    query = 'INSERT INTO session_test (Parcelle, Date, Annee, Latitude, Longitude, PHFB, type_mesure) VALUES (' + "'" + parcel + "'" + ', ' + "'" + date + "'" + ', ' + "'" + year + "'" + ', ' + "'" + latitude + "'" + ', ' + "'" + longitude + "'" + ', ' + "'" + value + "'" + ', ' + "'" + measureType + "'" + ')'
    cursor.execute(query)
    db_phfb.commit()
    cursor.close()

# get the mean latitude and longitude of the measures done on a specified parcel
def getParcelCoordinates(parcel):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    query = 'SELECT avg(CAST(replace(session_test.Latitude,",", ".") as decimal(10,8))), avg(cast(replace(session_test.Longitude, ",",".") as decimal(10,8))) FROM `session_test` where parcelle = ' + '"' + parcel + '"'
    cursor.execute(query)
    data = cursor.fetchall()

    cursor.close()

    for row in data:
        return {
            'meanLatitude': row[0],
            'meanLongitude': row[1],
        }
        