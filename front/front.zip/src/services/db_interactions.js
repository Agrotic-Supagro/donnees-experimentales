// const baseURL = `http://localhost:5001/`;
const baseURL = 'https://donnees-exp-back-dev.servadmin.fr/';

// import measures
export const importMeasures = async (measuresFile) => {
//   const token = localStorage.getItem('token');
  try{
    const formData = new FormData();
    formData.append('measuresFile', measuresFile);
      // fetch the data
      const res = await fetch(baseURL + 'importMeasures', {
          method: 'POST',
        //   headers: {
        //       // 'content-Type': 'application/csv',
        //       'Authorization': `Bearer ${token}`
        //   },
          body: formData
      });
      if (!res.ok) {
        const message = 'Error';
        throw new Error(message);
      }
      
      const result = await res.json();

      return result;

      } catch(error) {
          console.error(error.message);
      }
};

// download all measures
export const downloadAllMeasures = async () => {
    try{
        // fetch the data
        const res = await fetch(baseURL + 'downloadAllMeasures', {
            method: 'GET',
        });
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const result = await res.json();
  
        return result;
  
        } catch(error) {
            console.error(error.message);
        }
  };







