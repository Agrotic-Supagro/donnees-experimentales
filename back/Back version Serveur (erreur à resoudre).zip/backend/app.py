import sys
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
from db import *
from dotenv import load_dotenv
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity

load_dotenv()

'initialize flask app'
app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'hul_r22okle'
jwt = JWTManager(app)
CORS(app)
# app.register_blueprint(user, url_prefix='/user')


@app.route('/', methods=['GET'])
def hello_world():
    # app.logger.info('Hello, aurelien!')
    return jsonify('Hello, from experimental data!')


@app.route('/test')
def main():
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    cursor.execute('SELECT * FROM parcelles')
    cursor.fetchall()
    number_of_rows = cursor.rowcount
    app.logger.info(number_of_rows)
    cursor.close()
    return jsonify('nombre de parcelles : ' + str(number_of_rows))



# get all measures from DB
@app.route('/downloadAllMeasures', methods=['GET'])
def downloadAllMeasures():
    checkConnection(db_exp_data)
    cursor = db_exp_data.cursor()
    cursor.execute('select * from mesures')
    data = cursor.fetchall()
    cursor.close()
    result = []
    for row in data:
        result.append({
            'operateur':row[4],
            'placette':row[3],
            'date':row[1],
            'heure':row[2],
            'type_mesure':row[5],
            'id_equipement':row[6],
            'unite':row[7],
            'rognage':row[8],
            'phenologie':row[9],
            'remarque_meteo':row[10],
            'valeur':row[11],
            'formatted_date':row[12],
        })
    return jsonify(result)

# import measures into DB
@app.route('/importMeasures', methods=['POST'])
def importMeasures():
    checkConnection(db_exp_data)
    cursor = db_exp_data.cursor()
    # get file
    measuresFile = request.files['measuresFile']
    importFile(measuresFile, cursor)
    db_exp_data.commit()
    cursor.close()
    return '1'

def importFile(measuresFile, cursor):
    line = measuresFile.readline() # skip hearder line
    measures_values = []
    # loop over all lines
    while True:
        line = measuresFile.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get attributes
        operateur = attributes[0]
        placette = attributes[1]
        date = attributes[2]
        heure = attributes[3]
        type_mesure = attributes[4]
        identifiant_equipement = attributes[5]
        unite = attributes[6]
        valeur = attributes[7]
        rognage = attributes[8]
        remarque_meteo = attributes[9]
        phenologie = attributes[10]
        measures_values.append((date, heure, placette, operateur, type_mesure, identifiant_equipement, unite, rognage, phenologie, remarque_meteo, valeur))

    values_string = ', '.join(str(t) for t in measures_values)
    query = f'INSERT INTO mesures (date, heure, placette, operateur, type_mesure, id_equipement, unite, rognage, phenologie, remarque_meteo, valeur) VALUES {values_string}'
    cursor.execute(query)
    
    # reset file's pointer to beginning of the file
    measuresFile.seek(0)
    return '1'

'run the flask app'
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')