SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

set global net_buffer_length=1000000; 
set global max_allowed_packet=10000000000000000000000000000000000000000000000000000;

COMMIT;

USE donnees_experimentation;

CREATE TABLE analyses_sol (
  `id_analyse_sol` int NOT NULL AUTO_INCREMENT,
  `%_argile` char(40) NOT NULL,
  `%_limon_fin` char(40) NOT NULL,
  `%_limon_grossier` char(40) NOT NULL,
  `%_sable_fin` char(40) NOT NULL,
  `%_sable_grossier` char(40) NOT NULL,
  `IPC` char(40) NOT NULL,
  `aptitude_fissuration` char(40) NOT NULL,
  `stabilite_structurale` char(40) NOT NULL,
  `risque_asphyxie` char(40) NOT NULL,
  `reaction_sol` char(40) NOT NULL,
  `niveau_calcaire` char(40) NOT NULL,
  PRIMARY KEY (`id_analyse_sol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE operateurs (
  `id_operateur` int NOT NULL AUTO_INCREMENT,
  `nom` char(40) NOT NULL,
  `prenom` char(40) NOT NULL,
  `organisme` char(40) NOT NULL,
  PRIMARY KEY (`id_operateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE stations (
  `id_station` int NOT NULL AUTO_INCREMENT,
  `nom` char(40) NOT NULL,
  PRIMARY KEY (`id_station`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE informations_agronomiques (
  `id_informations_agronomiques` int NOT NULL AUTO_INCREMENT,
  `cepage` char(40) NOT NULL,
  `plantation` char(40) NOT NULL,
  `densite` char(40) NOT NULL,
  `type_taille` char(40) NOT NULL,
  `pierosite` char(40) NOT NULL,
  `notateur` char(40) NOT NULL,
  `indice_ouverture_paysage` char(40) NOT NULL,
  `aire_aoc` char(40) NOT NULL,
  `enherbement` char(40) NOT NULL,
  `travail_sol` char(40) NOT NULL,
  `type_palissage` char(40) NOT NULL,
  `pourcentage_manquants` char(40) NOT NULL,
  `age_vignes` char(40) NOT NULL,
  `porte_greffe` char(40) NOT NULL,
  `densite_plantation` char(40) NOT NULL,
  `t_moy` char(40) NOT NULL,
  PRIMARY KEY (`id_informations_agronomiques`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE bulletins_meteo (
  `id_bulletin` int NOT NULL AUTO_INCREMENT,
  `date` char(40) NOT NULL,
  `id_station` int NOT NULL,
  `pluie` char(40) NOT NULL,
  `formatted_date` date GENERATED ALWAYS AS (date_format(str_to_date(`Date`,_utf8mb4'%d/%m/%Y'),_utf8mb4'%Y/%m/%d')) VIRTUAL,
  `t_moy` char(40) NOT NULL,
  PRIMARY KEY (`id_bulletin`),
  FOREIGN KEY (id_station) REFERENCES stations(id_station)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE placettes (
  `id_placette` int NOT NULL AUTO_INCREMENT,
  `nom` char(40) NOT NULL,
  `latitude` char(40) NOT NULL,
  `longitude` char(40) NOT NULL,
  `vigneron` char(40) NOT NULL,
  `id_station` int NOT NULL,
  `id_analyse_sol` int NOT NULL,
  `id_informations_agronomiques` int NOT NULL,
  FOREIGN KEY (id_station) REFERENCES stations(id_station),
  FOREIGN KEY (id_analyse_sol) REFERENCES analyses_sol(id_analyse_sol),
  FOREIGN KEY (id_informations_agronomiques) REFERENCES informations_agronomiques(id_informations_agronomiques),
  PRIMARY KEY (`id_placette`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE mesures (
  `id_mesure` int NOT NULL AUTO_INCREMENT,
  `date` char(40) NOT NULL,
  `heure` char(40) NOT NULL,
  `placette` char(40) NOT NULL,
  -- `id_placette` int,
  -- `id_operateur` int,
  `operateur` char(40) NOT NULL,
  `type_mesure` char(40) NOT NULL,
  `id_equipement` char(40) NOT NULL,
  `unite` char(40) NOT NULL,
  `rognage` char(40) NOT NULL,
  `phenologie` char(40) NOT NULL,
  `remarque_meteo` char(40) NOT NULL,
  `valeur` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `formatted_date` date GENERATED ALWAYS AS (date_format(str_to_date(`Date`,_utf8mb4'%d/%m/%Y'),_utf8mb4'%Y/%m/%d')) VIRTUAL,
  -- FOREIGN KEY (id_operateur) REFERENCES operateurs(id_operateur),
  -- FOREIGN KEY (id_placette) REFERENCES placettes(id_placette),
  PRIMARY KEY (`id_mesure`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;







