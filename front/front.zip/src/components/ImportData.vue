<template>
    <div class="container" >
        <h2 class="mainTitle">Import de données</h2>
        <div class="form-group">
            <div class="mainContainer">
                <!-- <p class="subTitle"><b>Import</b></p> -->
                <p class="subTitle"><a href="https://donnees-exp-dev.servadmin.fr/assets/Template données expérimentales.xlsx">Télécharger le fichier modèle</a></p>
                <input type="file" @change="measuresFileChange">
            </div>
            <div class="button">
                <button class="button" :disabled="this.measuresFile === null" type="submit" @click="clickButton">Valider</button>
            </div>
            <div class="downloadButton">
                <button class="downloadButton" @click="clickDownloadButton">
                    Télécharger données
                </button>
               
            </div>
            <a class="downloadLink" v-if="csvLink"  :href="csvLink" :download="exportFileName">Lien fichier</a>
        </div>
    </div>
    <div v-if="isDataLoading">
      <LoadingSpinner></LoadingSpinner>
    </div>
</template>


<script>
import * as db_interactions from '@/services/db_interactions.js'
import LoadingSpinner from "@/components/LoadingSpinner.vue"

export default{
    
    data () {
        return {
            isDataLoading: false,
            measuresFile: null,
            csvLink: null,
            exportFileName: 'Donnees.csv'
        }
    },
    components: {
        LoadingSpinner
    },
    methods:{
        async measuresFileChange(e){
            this.measuresFile = e.target.files[0];
        },
        async clickButton(){
            this.isDataLoading = true;
            // import measures
            await db_interactions.importMeasures(this.measuresFile);
            this.isDataLoading = false;
        },
        async clickDownloadButton() {
            this.isDataLoading = true;
            // import measures
            const res = await db_interactions.downloadAllMeasures();
            this.createFile(res);
            this.isDataLoading = false;
        },
        createFile(res){
            const csvRows = [];
            console.log('res: ', res);
            // Get headers
            const headers = ['operateur', 'placette', 'date', 'heure', 'type_mesure', 'id_equipement', 'unite', 'valeur', 'rognage', 'remarque_meteo', 'phenologie']
            // const headers = Object.keys(res[0]);
            csvRows.push(headers.join(','));

            // Loop over the rows
            for (const row of res) {
                const values = headers.map(header => JSON.stringify(row[header]));
                csvRows.push(values.join(','));
            }
            
            // console.log('csvRows: ', csvRows);

            const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
            // const url = window.URL.createObjectURL(blob);
            this.csvLink = window.URL.createObjectURL(blob);
            console.log('link: ', this.csvLink);
        }
    },
}
</script>

<style scoped>
      div.container {
        position: fixed;
        left: 0vw;
        top:6vh;
        width: 100vw;
        height: 94vh;
        background-color: hsl(180, 30%, 89%);
        z-index: 0;
    }



    .mainContainer {
        position: absolute;
        top: 20%;
        left: 45%;
    }



    a{
        margin-left: 0;
        padding-left: 0;
        left: -2px;
    }


    
    .dropDownContainer{
        position: absolute;
        top: 25%;
        left: 5%;
        margin-left: 0;
        padding-left: 0;
    }
    .button{
        position: absolute;
        top: 50%;
        left: 50%;
    }
    button{
        height:30px;
        font-weight: bold;
    }
    button:hover:enabled{
        cursor: pointer;
    }
    li{
        list-style-type: none;
        margin: 0px 5px;
    }



    /* styling for the grid */
    table {
      border-collapse: collapse;
      width: 100%;
      border: 2px solid #ddd; /* Add border to the table */
    }
    th, td {
      border: 1px solid #ddd; /* Add border to table cells */
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
    h2{
        margin-bottom: 20px;
        margin-left: 10px;
    }
    .mainTitle{
        text-align: center;
        padding-bottom: 20px;
    }
    .subTitle{
        margin-left: 0;
        padding-left: 0;
        position: relative;
        left: 0px;
    }
    li{
        margin-left: 0;
        padding-left: 0;
    }
    .close {
        font-size: 45px;
        font-weight: 500;
        display: inline-block;
        position: absolute;
        left: 1%;
        top: 0%;
        color:rgb(107, 102, 102);
    }
    .close:hover{
        cursor: pointer;
        color:rgb(51, 106, 87);
        transform:scale(1.1);
    }
    .downloadButton{
        position: absolute;
        top: 80%;
        left: 90%;
        height: 40px;
    }
    .downloadLink{
        position: absolute;
        top: 90%;
        left: 90%;
    }

</style>