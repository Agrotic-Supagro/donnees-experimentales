import mysql.connector
import os

# configure experimental data database connection
exp_data = {
    'user': os.getenv("MYSQL_USER"),
    'password': os.getenv("MYSQL_PASSWORD"),
    'host': os.getenv("MYSQL_HOST"),
    'port': os.getenv("MYSQL_PORT"),
    'database': "donnees_experimentation"
}
db_exp_data = mysql.connector.connect(**exp_data)
db_exp_data.autocommit = True

def checkConnection(db):
    db.ping(reconnect = True, attempts=3, delay=10)