import sys
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
from db import *
from spiderModelFunctions import *
from utils import *
from dotenv import load_dotenv
<<<<<<<< HEAD:backend/corbeille/app.py
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity
========
#from user import *
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity
#from user import user
>>>>>>>> 7fd30996c7fcf28381d3fc888ba1ada4c2f3d38b:backend/app.py

load_dotenv()

'initialize flask app'
app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'hul_r22okle'
jwt = JWTManager(app)
CORS(app)
# app.register_blueprint(user, url_prefix='/user')

<<<<<<<< HEAD:backend/corbeille/app.py
@app.route('/')
def hello_world():
    app.logger.info('Hello, World!')
    return 'Hello, World!'

========
# Handling CORS preflight requests
# @app.after_request
# def after_request(response):
#     response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
#     response.headers.add('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')
#     return response

@app.route('/', methods=['GET'])
def hello_world():
    # app.logger.info('Hello, aurelien!')
    return jsonify('Hello, aurelien!')

>>>>>>>> 7fd30996c7fcf28381d3fc888ba1ada4c2f3d38b:backend/app.py
@app.route('/test')
def main():
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    cursor.execute('SELECT * FROM parcelle')
    cursor.fetchall()
    number_of_rows = cursor.rowcount
    app.logger.info(number_of_rows)
    cursor.close()
<<<<<<<< HEAD:backend/corbeille/app.py
    return 'nombre de parcelles : ' + str(number_of_rows)
========
    return jsonify('nombre de parcelles : ' + str(number_of_rows))
>>>>>>>> 7fd30996c7fcf28381d3fc888ba1ada4c2f3d38b:backend/app.py

import mobile.sessions
import mobile.parcels
import user

#######################################################################################
#############################  MAP VISUALISATION FUNCTIONS  ###########################
#######################################################################################

'create a route in the flask app to retrieve data from the DB and return it as JSON'
# get ICAPEX measures between specified startDate and endDate
@app.route('/getICAPEXMeasures', methods=['GET'])
@jwt_required()
def getICAPEXMeasures():
    # get JWT token identity
<<<<<<<< HEAD:backend/corbeille/app.py
    current_user = get_jwt_identity()
    # Todo: use user's id (or email/identity) got from get_jwt_identity to make the request to avoid cheating on user's identity

========
    # current_user = get_jwt_identity()
    # print('current_user: ', current_user)
    # Todo: use user's id (or email/identity) got from get_jwt_identity to make the request to avoid cheating on user's identity
    
>>>>>>>> 7fd30996c7fcf28381d3fc888ba1ada4c2f3d38b:backend/app.py
    #get parameters
    startDate = request.args.get('startDate')
    endDate = request.args.get('endDate')
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
<<<<<<<< HEAD:backend/corbeille/app.py

========
    
>>>>>>>> 7fd30996c7fcf28381d3fc888ba1ada4c2f3d38b:backend/app.py
    # make request
    cursor.execute(
        'SELECT observation.id_session, AVG(observation.apex_value)/2 as apex_value, AVG(observation.latitude) as latitude, AVG(observation.longitude) as longitude, ' +
            ' session.date_session_test, parcelle.nom_parcelle FROM Observation ' + 
                'LEFT JOIN Session ON Observation.id_session = Session.id_session LEFT JOIN ' + 
                    'Parcelle ON Session.id_parcelle = Parcelle.id_parcelle ' + 
                        'WHERE session.date_session_test >= ' + '"' + startDate + '"' + ' AND session.date_session_test <= ' + '"' + endDate + '"' + ' GROUP BY observation.id_session LIMIT 5000'
    )
    data = cursor.fetchall()
    cursor.close()
    
    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[4],
            'parcel_name':row[5],
            'apex_value': row[1],
            'measure_type':'mesure',
            'type':'IC-APEX',
            'date':row[4],
            'reliability':'high',
            'latitude':row[2],
            'longitude':row[3],
        })

    return jsonify(result)


# get PHFB measures between specified startDate and endDate
@app.route('/getPHFBMeasures', methods=['GET'])
@jwt_required()
def getPHFBMeasures():
    # get parameters
    startDate = request.args.get('startDate')
    endDate = request.args.get('endDate')
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Date, session_test.Parcelle, session_test.PHFB, session_test.Latitude, session_test.Longitude, session_test.type_mesure FROM session_test ' 
            + 'WHERE session_test.formatted_date >= ' + '"' + startDate + '"' + ' AND session_test.formatted_date <= ' + '"' + endDate + '"'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[1],
            'parcel_name':row[2],
            'phfb_value': row[3],
            'measure_type':row[6],
            'type':'PHFB',
            'reliability': 'medium' if row[6] == 'estimation' else 'high',
            'latitude':row[4],
            'longitude':row[5],
        })

    return jsonify(result)

#######################################################################################
#############################  PARCEL VISUALISATION FUNCTIONS  ########################
#######################################################################################

# get all the measures (PHFB and ICAPEX) of a specified parcel
@app.route('/getParcelMeasures', methods=['GET'])
def getParcelMeasures():
    # get parameters
    parcel = request.args.get('parcel')

    # get measures 
    parcelPHFBMeasures = getParcelPHFBMeasures(parcel)
    parcelICAPEXMeasures = getParcelICAPEXMeasures(parcel)

    # merge PHFB and ICAPEX measures
    parcelMeasures = parcelPHFBMeasures + parcelICAPEXMeasures
    
    return jsonify(parcelMeasures)

# get all the PHFB measures of a specific parcel
def getParcelPHFBMeasures(parcel):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Date, session_test.Parcelle, session_test.PHFB, session_test.Latitude, session_test.Longitude, session_test.type_mesure FROM session_test ' 
            + 'WHERE session_test.Parcelle = ' + '"' + parcel + '"'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[1],
            'parcel_name':row[2],
            'measure_value': row[3],
            'measure_type':row[6],
            'type':'PHFB',
            'unit':'hPa',
            'reliability': 'medium' if row[6] == 'estimation' else 'high',
            'latitude':row[4],
            'longitude':row[5],
        })
    return result

def getParcelICAPEXMeasures(parcel):
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    # make request
    cursor.execute(
        'SELECT observation.id_session, AVG(observation.apex_value)/2 as apex_value, AVG(observation.latitude) as latitude, AVG(observation.longitude) as longitude, ' +
            ' session.date_session_test, parcelle.nom_parcelle FROM Observation ' + 
                'LEFT JOIN Session ON Observation.id_session = Session.id_session LEFT JOIN ' + 
                    'Parcelle ON Session.id_parcelle = Parcelle.id_parcelle ' + 
                        'WHERE Parcelle.nom_parcelle = ' + '"' + parcel + '"' + ' GROUP BY observation.id_session'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[4],
            'parcel_name':row[5],
            'measure_value': row[1],
            'measure_type':'mesure',
            'type':'IC-APEX',
            'unit':'-',
            'date':row[4],
            'reliability':'high',
            'latitude':row[2],
            'longitude':row[3],
        })
    return result

# get all parcel names (from PHFB and IC-APEX databases)
@app.route('/getParcelNames', methods=['GET'])
def getParcelNames():
    parcelNamesPHFB = getParcelNamesPHFB()
    parcelNamesICAPEX = getParcelNamesICAPEX()
    print(len(parcelNamesPHFB + parcelNamesICAPEX))
    return jsonify(parcelNamesPHFB + parcelNamesICAPEX)

def getParcelNamesICAPEX():
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    # make request
    cursor.execute( # REPDRENDRE ICI
        'SELECT  ' +
            ' parcelle.id_parcelle, parcelle.nom_parcelle FROM Parcelle '
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'name': row[1],
        })
    return result



#######################################################################################
#############################  SPIDER MODEL FUNCTIONS  ################################
#######################################################################################

# TODO: verify this function, especially when checking time frames (to know if current date hasn't been yet checked)
@app.route('/getValidSeasonsSpiderModel', methods=['GET'])
# returns a list of the seasons valid for spider model
def getValidSeasonsSpiderModel():
    validSeasons = []
    validParcels = {}
    # get all seasons for phfb measures
    phfbSeasons = getSeasonsPHFB()
    print('phfbSeasons: ', phfbSeasons)
    # check validity of each season
    for season in phfbSeasons:
        # get valid parcels for current season
        validParcels[season] = validParcelsSpiderModel(season)
        # if there is more than one valid parcel the season is valid
        if len(validParcels) > 0:
            validSeasons.append(season)

    return jsonify([validSeasons, validParcels])

@app.route('/computeSpiderCoefficients', methods=['GET'])
# compute and returns the ASI coefficients between the reference parcel and each one of the satellite parcels for the specified seasons
def computeSpiderCoefficients():
    # get parameters
    seasons = request.args.get('seasons').split(',')
    candidateSatelliteParcels = request.args.get('candidateSatelliteParcels').split(',')
    refParcel = request.args.get('refParcel')
    
    # get asi coeffs
    coeffs = getSpiderCoefficients(seasons, candidateSatelliteParcels, refParcel)

    # save coeffs on DB
    saveCoeffs(coeffs, refParcel)

    return coeffs

# save asi coefficients on DB
def saveCoeffs(coeffs, refParcel):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # delete existing coeffs
    cursor.execute('DELETE FROM coefficients')

    # iterate over coefficients to save
    for coeff in coeffs:
        # delete potential pre-existing coeffs for current parcel and refParcel - TODO: make this isn't relevant to do it and delete it
        # cursor.execute('DELETE FROM coefficients WHERE coefficients.parcel = ' + '"' + coeff['parcel'] + '"' + ' and coefficients.refParcel = ' + '"' + refParcel + '"')
        
        # insert coeff values
        query = 'INSERT INTO coefficients (parcel, coeff, refParcel) VALUES (%s, %s, %s)'
        values = (coeff['parcel'], coeff['coeff'], refParcel)
        cursor.execute(query, values)
    db_phfb.commit()
    cursor.close()

@app.route('/getCoeffs', methods=['GET'])
# returns the spider coefficients stored in the DB
def getCoeffs():
    return getCoefficients()



@app.route('/testingMethod', methods=['GET'])
def testingMethod():
    coord = getParcelCoordinates('Pilotype gr 17')
    return coord


# get PHFB measures of a specific parcel
# @app.route('/getPHFBMeasuresParcel', methods=['GET'])
# def getPHFBMeasuresParcel():
#     # get parameters
#     parcel = request.args.get('parcel')
#     checkConnection(db_phfb)
#     cursor = db_phfb.cursor()

#     cursor.execute(
#         'SELECT * FROM session_test ' 
#             + 'WHERE session_test.formatted_date >= ' + '"' + startDate + '"' + ' AND session_test.formatted_date <= ' + '"' + endDate + '"'
#     )


# get parcel names from PHFB DB
@app.route('/getParcelsPHFB', methods=['GET'])
def getParcelsPHFB():
    return jsonify(getParcelNamesPHFB())

@app.route('/insertPHFBMeasure', methods=['POST'])
def insertPHFBMeasure():
    print('insertPHFBMeasure')
    # get parameters
    value = request.args.get('value')
    parcel = request.args.get('parcel')
    date = datetime.strptime(request.args.get('date'), "%Y-%m-%d").date()
    year = str(date.year)
    date = changeDateFormatDayMonthYear(date)
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    
    # insert new row
    query = 'INSERT INTO session_test (Parcelle, Date, Annee, Latitude, Longitude, PHFB) VALUES (' + "'" + parcel + "'" + ', ' + "'" + date + "'" + ', ' + "'" + year + "'" + ', ' + "'" + latitude + "'" + ', ' + "'" + longitude + "'" + ', ' + "'" + value + "'" ')'
    cursor.execute(query)
    db_phfb.commit()
    cursor.close()

    # check if there is an existing spider model
    refParcel = getRefParcelSpiderModel()
    print('refParcel: ', refParcel)
    if refParcel is not None:
        # check if the added parcel is the ref parcel
        if parcel == refParcel:
            # compute estimations for satellite parcels 
            computeEstimationFromRefParcel(refParcel, value, date, year)


    return ''

    
'run the flask app'
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
